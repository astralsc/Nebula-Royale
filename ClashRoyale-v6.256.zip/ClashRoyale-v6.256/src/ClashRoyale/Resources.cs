﻿using ClashRoyale.Core;
using ClashRoyale.Core.Cluster;
using ClashRoyale.Core.Leaderboard;
using ClashRoyale.Core.Network;
using ClashRoyale.Database;
using ClashRoyale.Database.Cache;
using ClashRoyale.Files;
using ClashRoyale.Files.Logic;
using ClashRoyale.Logic.Manager;
using ClashRoyale.Utilities.Utils;
using System;
using System.Threading.Tasks;

namespace ClashRoyale
{
    public static class Resources
    {
        public static Logger Logger { get; set; }
        public static SentryReport Sentry { get; set; }
        public static Configuration Configuration { get; set; }

        public static PlayerDb PlayerDb { get; set; }

        public static AllianceDb AllianceDb { get; set; }
        public static ObjectCache ObjectCache { get; set; }
        public static Leaderboard Leaderboard { get; set; }

        public static NettyService Netty { get; set; }
        public static NodeManager NodeManager { get; set; }

        public static Fingerprint Fingerprint { get; set; }
        public static Csv Csv { get; set; }

        public static Players Players { get; set; }
        public static Alliances Alliances { get; set; }

        public static DateTime StartTime { get; set; }

        public static async void Initialize()
        {
            Logger = new Logger();
            Logger.Log(
                $"Starting [{DateTime.Now.ToLongTimeString()} - {ServerUtils.GetOsName()}]...",
                null);

            Configuration = new Configuration();
            Configuration.Initialize();

            NodeManager = new NodeManager();

            Fingerprint = new Fingerprint();
            Csv = new Csv();

            PlayerDb = new PlayerDb();
            AllianceDb = new AllianceDb();

            Logger.Log(
                $"Successfully loaded MySql with {await PlayerDb.CountAsync()} player(s) & {await AllianceDb.CountAsync()} clan(s)",
                null);

            ObjectCache = new ObjectCache();

            Players = new Players();
            Alliances = new Alliances();

            Leaderboard = new Leaderboard();

            StartTime = DateTime.UtcNow;

            Netty = new NettyService();

            await Task.Run(Netty.RunServerAsync);
        }
    }
}