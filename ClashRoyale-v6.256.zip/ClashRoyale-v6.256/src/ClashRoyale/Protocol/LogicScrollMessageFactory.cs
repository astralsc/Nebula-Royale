﻿using System;
using System.Collections.Generic;
using ClashRoyale.Protocol.Messages.Client;
/*using ClashRoyale.Protocol.Messages.Client.Alliance;
using ClashRoyale.Protocol.Messages.Client.Home;*/
using ClashRoyale.Protocol.Messages.Client.Login;
//using ClashRoyale.Protocol.Messages.Client.Scoring;

namespace ClashRoyale.Protocol
{
    public class LogicScrollMessageFactory
    {
        public static Dictionary<int, Type> Messages;

        static LogicScrollMessageFactory()
        {
            Messages = new Dictionary<int, Type>
            {
                {10100, typeof(ClientHelloMessage)},
                {10101, typeof(LoginMessage)},
                {10108, typeof(KeepAliveMessage)}
            };
        }
    }
}