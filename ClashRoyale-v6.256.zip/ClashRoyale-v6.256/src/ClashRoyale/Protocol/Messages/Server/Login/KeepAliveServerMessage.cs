﻿using ClashRoyale.Logic;
using ClashRoyale.Utilities.Netty;

namespace ClashRoyale.Protocol.Messages.Server
{
    public class KeepAliveServerMessage : PiranhaMessage
    {
        public KeepAliveServerMessage(Device device) : base(device)
        {
            Id = 20108;
            Version = 1;
        }

        public override void Encode()
        {
            Writer.WriteHex("FFFF0000000000");
        }
    }
}