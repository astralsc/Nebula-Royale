﻿using System;
using ClashRoyale.Logic;

namespace ClashRoyale.Protocol.Messages.Server.Security
{
    class ServerHelloMessage : PiranhaMessage
    {
        public ServerHelloMessage(Device device) : base(device)
        {
            Id = 20100;
        }

        public override void Encode()
        {
            Writer.WriteInt(24);
            Random rnd = new Random();
            for (byte i = 0; i < 24; i++)
            {
                Writer.WriteByte((byte)rnd.Next(0, 255));
            }
        }
    }
}