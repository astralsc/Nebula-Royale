﻿using ClashRoyale.Logic;
using ClashRoyale.Logic.Home;
using ClashRoyale.Utilities.Netty;
using Org.BouncyCastle.Bcpg;
using System;
using System.Net.Sockets;

namespace ClashRoyale.Protocol.Messages.Server
{
    public class OwnHomeDataMessage : PiranhaMessage
    {
        public OwnHomeDataMessage(Device device) : base(device)
        {
            Id = 21463;
            Version = 10;
            device.CurrentState = Device.State.Home;
            Device.LastVisitHome = DateTime.UtcNow;
        }

        public override void Encode()
        {
            var player = Device.Player;

            player.Home.Tick();

            player.LogicClientHome(Writer);
            player.LogicClientAvatar(Writer);

            Writer.WriteVInt(0);
            Writer.WriteVInt(0);
            Writer.WriteVInt(0);
            Writer.WriteVInt(0);
            Writer.WriteVInt(0);
        }
    }
}