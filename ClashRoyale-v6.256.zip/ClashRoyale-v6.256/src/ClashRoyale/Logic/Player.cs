﻿using ClashRoyale.Database;
using ClashRoyale.Files.CsvUtils;
using ClashRoyale.Logic.Clan;
using ClashRoyale.Logic.Manager.Items;
using ClashRoyale.Logic.Sessions;
using ClashRoyale.Utilities.Netty;
using ClashRoyale.Utilities.Utils;
using DotNetty.Buffers;
using MySqlX.XDevAPI.Common;
using Newtonsoft.Json;
using System;

namespace ClashRoyale.Logic
{
    public class Player
    {
        public Player(long id)
        {
            Home = new Home.Home(id, GameUtils.GenerateToken);
        }

        public Player()
        {
            // Player.
        }

        public Home.Home Home { get; set; }

        [JsonIgnore] public Device Device { get; set; }

        public void RankingEntry(IByteBuffer packet)
        {
            // TODO
        }

        public void LogicClientHome(IByteBuffer packet)
        {
            packet.WriteLong(Home.Id);

            for (int i = 0; i < 6; i++) packet.WriteVInt(0);

            packet.WriteVInt(8); // CardsCount
            {
                packet.WriteInt(26000000);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);

                packet.WriteInt(26000001);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);

                packet.WriteInt(26000002);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);

                packet.WriteInt(26000003);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);

                packet.WriteInt(26000004);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);

                packet.WriteInt(26000005);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);

                packet.WriteInt(26000006);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);

                packet.WriteInt(26000007);
                packet.WriteVInt(1);
                for (int i = 0; i < 9; i++) packet.WriteVInt(0);
            }

            packet.WriteVInt(0);

            packet.WriteVInt(8); // DeckSlotCount
            {
                packet.WriteVInt(1);
                packet.WriteInt(26000000); // Slot1
                packet.WriteInt(26000001); // Slot2
                packet.WriteInt(26000002); // Slot3
                packet.WriteInt(26000003); // Slot4
                packet.WriteInt(26000004); // Slot5
                packet.WriteInt(26000005); // Slot6
                packet.WriteInt(26000006); // Slot7
                packet.WriteInt(26000007); // Slot8
            }

            packet.WriteInt(0);

            for (int i = 0; i < 6; i++) packet.WriteVInt(0);

            packet.WriteVInt(1);

            for (int i = 0; i < 15; i++) packet.WriteVInt(0);

            packet.WriteVInt(1); 

            packet.WriteVInt(0); 

            packet.WriteVInt(4);

            for (int i = 0; i < 67; i++) packet.WriteVInt(0);

            packet.WriteVInt(8);

            packet.WriteVInt(1);

            for (int i = 0; i < 10; i++) packet.WriteVInt(0);

            packet.WriteVInt(1);

            for (int i = 0; i < 181; i++) packet.WriteVInt(0);

            packet.WriteVInt(1);

            for (int i = 0; i < 54; i++) packet.WriteVInt(0);

            packet.WriteVInt(1);

            for (int i = 0; i < 57; i++) packet.WriteVInt(0);
        }

        public void LogicClientAvatar(IByteBuffer packet)
        {
            // Id - Account Id - HomeId
            for (var i = 0; i < 3; i++)
            {
                packet.WriteVInt(Home.HighId);
                packet.WriteVInt(Home.LowId);
            }

            // Name
            {
                packet.WriteScString(Home.NameSet > 0 ? Home.Name : null);
            }

            packet.WriteVInt(2); // State (1, 3, 4, ... = Trophy Road Change, 2 = Legendary Trophy Popup);
            packet.WriteVInt(0); // Trophies
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0); // LegendaryTrophies

            packet.WriteVInt(1); // 1 = Already saw Legendary Trophy popup
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);
            packet.WriteVInt(0);

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0);
            {
            }

            packet.WriteVInt(0); // 0 = No name popup, 1 = Name popup

            packet.WriteVInt(100); // Diamonds
            packet.WriteVInt(100); // FreeDiamonds
            packet.WriteVInt(1); // ExpLevel
            packet.WriteVInt(0); // ExpPoints

            packet.WriteVInt(0);
            packet.WriteVInt(1);
            packet.WriteVInt(0); // 13
            for (var i = 0; i < 7; i++) packet.WriteVInt(0);
            packet.WriteVInt(7); // Tutorial???
            for (var i = 0; i < 36; i++) packet.WriteVInt(0);
        }

		public void AvatarRankingEntry(IByteBuffer packet, int order, bool isPrevious = false)
		{
			RankingEntry(packet, order, isPrevious);

			packet.WriteInt(Home.ExpLevel);
			packet.WriteInt(Home.AttacksWon); //attacks won
			packet.WriteInt(0);
			packet.WriteInt(Home.DefensesWon); //defenses won
			packet.WriteInt(0);
			packet.WriteInt(LeagueUtils.GetLeagueByScore(isPrevious ? Home.PreviousSeasonTrophies : Home.League > 0 ? Home.Trophies : 0));

			packet.WriteScString(Home.PreferredDeviceLanguage);
			packet.WriteLong(Home.Id);

			packet.WriteInt(0);
			packet.WriteInt(0);

			AllianceInfo info = Home.AllianceInfo;

			if (info.HasAlliance)
			{
				packet.WriteBoolean(true);
				{
					packet.WriteLong(info.Id);
					packet.WriteScString(info.Name);
					packet.WriteInt(info.Badge);
				}
			}
			else
			{
				packet.WriteBoolean(false);
			}
		}

		public void LeagueMemberEntry(IByteBuffer packet, int order)
		{
			packet.WriteLong(Home.Id);
			packet.WriteScString(Home.Name);
			packet.WriteInt(order);
			packet.WriteInt(Home.Trophies);
			packet.WriteInt(0);
			packet.WriteInt(0);
			packet.WriteInt(Home.AttacksWon); //attacks won
			packet.WriteInt(0);
			packet.WriteInt(Home.DefensesWon); //defenses won
			packet.WriteInt(0);

			packet.WriteLong(Home.Id);
			packet.WriteLong(Home.Id);

			AllianceInfo info = Home.AllianceInfo;

			if (info.HasAlliance)
			{
				packet.WriteBoolean(true);
				{
					packet.WriteLong(info.Id);
					packet.WriteScString(info.Name);
					packet.WriteInt(info.Badge);
				}
			}
			else
			{
				packet.WriteBoolean(false);
			}

			packet.WriteLong(Home.Id);

		}

		private void RankingEntry(IByteBuffer packet, int order, bool isPrevious = false)
		{
			packet.WriteLong(Home.Id);
			packet.WriteScString(Home.Name);

			packet.WriteInt(order);
			packet.WriteInt(isPrevious ? Home.PreviousSeasonTrophies : Home.Trophies);
			packet.WriteInt(200);
		}

		/*public async void AddEntry(AvatarStreamEntry entry)
        {
            lock (Home.Stream)
            {
                while (Home.Stream.Count >= 40)
                    Home.Stream.RemoveAt(0);

                var max = Home.Stream.Count == 0 ? 1 : Home.Stream.Max(x => x.Id);
                entry.Id = max == int.MaxValue ? 1 : max + 1; // If we ever reach that value... but who knows...

                Home.Stream.Add(entry);
            }

            await new AvatarStreamEntryMessage(Device)
            {
                Entry = entry
            }.SendAsync();
        }*/

		/// <summary>
		///     Validates this session
		/// </summary>
		public void ValidateSession()
		{
			Session session = Device.Session;
			session.Duration = (int)DateTime.UtcNow.Subtract(session.SessionStart).TotalSeconds;

			Home.TotalPlayTimeSeconds += session.Duration;

			while (Home.Sessions.Count >= 50) Home.Sessions.RemoveAt(0);

			Home.Sessions.Add(session);
		}

		public async void Save()
		{
			Home.LastSaveTime = DateTime.UtcNow;
			/*#if DEBUG
						var st = new Stopwatch();
						st.Start();

						Resources.ObjectCache.CachePlayer(this);
						await PlayerDb.SaveAsync(this);

						st.Stop();
						Logger.Log($"Player {Home.Id} saved in {st.ElapsedMilliseconds}ms.", GetType(), ErrorLevel.Debug);
			#else*/
			Resources.ObjectCache.CachePlayer(this);
			await PlayerDb.SaveAsync(this);
			//#endif
		}

		public async void SaveAll()
		{
			Home.Status = 0;
			Home.LastSaveTime = DateTime.UtcNow;
			/*#if DEBUG
                        var st = new Stopwatch();
                        st.Start();

                        Resources.ObjectCache.CachePlayer(this);
                        await PlayerDb.SaveAsync(this);

                        st.Stop();
                        Logger.Log($"Player {Home.Id} saved in {st.ElapsedMilliseconds}ms.", GetType(), ErrorLevel.Debug);
            #else*/
			Resources.ObjectCache.CachePlayer(this);
			await PlayerDb.SaveAsync(this);
			//#endif
		}
    }
}