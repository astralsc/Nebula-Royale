﻿using Newtonsoft.Json;

namespace ClashRoyale.Logic.Manager
{
	public class SettingsManager
	{
		[JsonProperty("triggerHeroAbilityOnDeath")] public int TriggerHeroAbilityOnDeath { get; set; }

		public void SetTriggerHeroAbilityOnDeath(int state)
		{
			TriggerHeroAbilityOnDeath = state;
		}
	}
}