﻿using System;
using System.IO;
using NLog;

namespace ClashRoyale
{
    public class Logger
    {
        public enum ErrorLevel
        {
            Info,
            Warning,
            Error,
            Debug
        }

#if DEBUG
        private static readonly object ConsoleSync = new object();
#endif

        private static readonly NLog.Logger _logger;

        static Logger()
        {
            Directory.CreateDirectory("Logs");

            _logger = LogManager.GetCurrentClassLogger();
        }

        public Logger()
        {
        }

        public static void Log(object message, Type type, ErrorLevel logType = ErrorLevel.Info)
        {
            switch (logType)
            {
                case ErrorLevel.Info:
                    {
                        _logger.Info(message);

                        Console.WriteLine($"[{logType}] {message}");
                        break;
                    }

                case ErrorLevel.Warning:
                    {
                        _logger.Warn(message);
#if DEBUG
                        lock (ConsoleSync)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkMagenta;
                            Console.WriteLine($"[{logType}] {message}");
                            Console.ResetColor();
                        }
#endif

                        //Resources.Sentry.Report(message.ToString(), type, ToSentryLevel(logType));
                        break;
                    }

                case ErrorLevel.Error:
                    {
                        _logger.Error(message);
#if DEBUG
                        lock (ConsoleSync)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"[{logType}] {message}");
                            Console.ResetColor();
                        }
#endif

                        //Resources.Sentry.Report(message.ToString(), type, ToSentryLevel(logType));
                        break;
                    }

                case ErrorLevel.Debug:
                    {
#if DEBUG
                        _logger.Debug(message);

                        lock (ConsoleSync)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine($"[{logType}] {message}");
                            Console.ResetColor();
                        }
#endif
                        break;
                    }
            }
        }

        public static void Log(object message, Type type, SharpRaven.Data.ErrorLevel logType)
        {
            Log(message, type, FromSentryLevel(logType));
        }

        private static ErrorLevel FromSentryLevel(SharpRaven.Data.ErrorLevel level)
        {
            switch (level)
            {
                case SharpRaven.Data.ErrorLevel.Warning: return ErrorLevel.Warning;
                case SharpRaven.Data.ErrorLevel.Error:
                case SharpRaven.Data.ErrorLevel.Fatal: return ErrorLevel.Error;
                case SharpRaven.Data.ErrorLevel.Debug: return ErrorLevel.Debug;
                default: return ErrorLevel.Info;
            }
        }

        private static SharpRaven.Data.ErrorLevel ToSentryLevel(ErrorLevel level)
        {
            switch (level)
            {
                case ErrorLevel.Warning: return SharpRaven.Data.ErrorLevel.Warning;
                case ErrorLevel.Error: return SharpRaven.Data.ErrorLevel.Error;
                case ErrorLevel.Debug: return SharpRaven.Data.ErrorLevel.Debug;
                default: return SharpRaven.Data.ErrorLevel.Info;
            }
        }
    }
}