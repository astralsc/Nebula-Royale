# ClashRoyale (2024)
[![clash royale](https://img.shields.io/badge/Clash%20Royale-6.256.21-brightred.svg?style=flat")](https://clash-royale.uptodown.com/android/descargar/1008794013-x)
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
![Build Status](https://action-badges.now.sh/Incr3dible/ClashRoyale)

#### A .NET Core Clash Royale Server (v6.256)
##### Need help? Join our [Discord](https://discord.gg/8cHkNE6)

## Battles
The server supports battles, for those a patched client is neccessary.

[See the wiki for a tutorial](https://github.com/Incr3dible/ClashRoyale/wiki/Patch-for-battles)

## How to start

#### Requirements:
  - [.NET Core 10.0](https://dotnet.microsoft.com/en-us/download/dotnet/10.0)
  - MySql Database (on Debian i suggest LAMP with PhpMyAdmin)

for Ubuntu use these commands to set it up:

###### Main Server:
```
mkdir ClashRoyale
git clone https://github.com/Incr3dible/ClashRoyale.git && cd ClashRoyale/src/ClashRoyale

dotnet publish "ClashRoyale.csproj" -c Release -o app
```
###### Battle Server:
```
mkdir ClashRoyaleBattles
git clone https://github.com/Incr3dible/ClashRoyale.git ClashRoyaleBattles && cd ClashRoyaleBattles/src/ClashRoyale.Battles

dotnet publish "ClashRoyale.Battles.csproj" -c Release -o app
```
To configurate your server, such as the database you have to edit the ```config.json``` file.

#### Run the server:

###### Main Server:
```dotnet app/ClashRoyale.dll```

###### Battle Server:
```dotnet app/ClashRoyale.Battles.dll```

#### Update the server:
###### Main Server:
```git pull && dotnet publish "ClashRoyale.csproj" -c Release -o app && dotnet app/ClashRoyale.dll```

###### Battle Server:
```git pull && dotnet publish "ClashRoyale.Battles.csproj" -c Release -o app && dotnet app/ClashRoyale.Battles.dll```

## Need help?
Contact me on Discord (Incredible#2109) or open an issue.
