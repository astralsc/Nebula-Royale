const Config = {
    Host: '192.168.1.108',
    Port: '9339'
}

const Offsets = {
    Messaging: {
        send: 0xA024DC,
        sendPepperAuthentication: 0xA03604
    },
    PepperCrypto: {
        secretbox_open: 0xA03158
    }
}
const base = Process.getModuleByName("libg.so").base;
const Messagingsend = new NativeFunction(base.add(Offsets.Messaging.send), 'bool', ['pointer', 'pointer'])

const PepperKiller = {
    init(shouldKillEncryption, shoudKillDecryption) {
        if (shouldKillEncryption) this.killEncryption()
        if (shoudKillDecryption) this.killDecryption()
    },
    killEncryption() {
        Interceptor.replace(base.add(Offsets.Messaging.sendPepperAuthentication), new NativeCallback(function (a1, a2) {
            a1.add(24).writeU8(5);
            Messagingsend(a1, a2); // skip any encryption or auth, send immediately
        }, "void", ["pointer", "pointer"],),);
    },
    killDecryption() {
        try {
            Interceptor.replace(base.add(Offsets.PepperCrypto.secretbox_open), new NativeCallback(function() {
                console.warn("[+][PepperCrypto::secretbox_open] Skipped decryption");
                return 1; // skip any decryption and return success immediately
            }, 'int', []));
        }
        catch (e) {
            console.warn("[+] PepperCrypto::secretbox_open is already skipped! ", e) // to prevent frida erroring
        }        
    }
}

Interceptor.attach(Module.getGlobalExportByName('getaddrinfo'), {
    onEnter(args) {
        if (args[1].readUtf8String() === "9339") {
            args[0].writeUtf8String(Config.Host)
            args[1].writeUtf8String(Config.Port)
        }

        PepperKiller.init(true, true)
    }
});